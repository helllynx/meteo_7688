# SFE_BMP180
SFE_BMP180 Arduino barometer library

Copy from Sparkfun. Arduino library for BMP180 Bosch barometric pressure/temperature sensors. Install as usual in your Arduino/libraries folder, restart IDE.

====

Копия библиотеки для работы с термометром и барометром BMP180 для Arduino. Скопировать в папку Arduino/libraries и перезапустить IDE.
Примеры использования библиотеки в папке examples
